// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there. 
// 
// Exit codes: 
// 0 = success, valid input stored 
// 2 = user aborted (typed "quit") 
// 3 = too many invalid attempts / overflow rejected 
// 4 = input / stream error (EOF) 
#include <iomanip> 
#include <iostream>
#include <string> 
#include <cstring> 


int main() { 
	
	std::cout << "Buffer Overflow Example" << std::endl; 
	
	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced - 
	// even though it is a constant and the compiler buffer overflow checks are on. 
	// You need to modify this method to prevent buffer overflow without changing the account_number 
	// variable, and its position in the declaration. It must always be directly before the variable used for input. 
	// You must notify the user if they entered too much data. 
	
	const std::string account_number = "CharlieBrown42"; 
	char user_input[20]; 
	
	const std::size_t buffer_size = sizeof(user_input); 
	const std::size_t max_chars = buffer_size - 1; 
	const int max_attempts = 3; 
	
	std::string raw_line; 
	int attempts = 0; 
	bool valid = false; 
	
	// Loop to allow three attempts to enter correct input 
	while (attempts < max_attempts) { 
		std::cout << "Enter a value (max " << max_chars << " characters): "; 
		if (!std::getline(std::cin, raw_line)) { 
			std::cerr << "Input error or EOF detected.\n"; return 4; // notify caller of input error 
		} 
		
		//Allows user to quit if desired 
		if (raw_line == "quit" || raw_line == "Quit") { 
			std::cout << "User requested abort.\n"; return 2; //notify caller of user termination
		} 
		
		//Checks if input is empty 
		if (raw_line.empty()) {
			++attempts; 
			std::cout << "Empty input. Please enter some text. " << (max_attempts - attempts) << " attempts remaining.\n"; 
			continue; 
		} 
		
		//Correct input length 
		if (raw_line.size() <= max_chars) { 
			std::size_t to_copy = raw_line.size(); 
			raw_line.copy(user_input, to_copy); 
			user_input[to_copy] = '\0'; // Explicitly terminate 
			valid = true; 
			break; 
		} 
		
		// Input too long: 
		++attempts; 
		std::cout << "ERROR: Input too long (" << raw_line.size() << " characters). " << "Maximum allowed is " << max_chars << ". " << (max_attempts - attempts) << " attempts remaining.\n"; 
	
	} if (!valid) { 
		//After retry limit, reject safely and provide a safe fallback value. 
		const char fallback[] = "(rejected)"; 
		std::size_t fallback_len = std::strlen(fallback); 
		std::size_t copy_len = (fallback_len <= max_chars) ? fallback_len : max_chars; 
		std::memcpy(user_input, fallback, copy_len); 
		user_input[copy_len] = '\0'; 
		
		// Display the overflow condition 
		std::cout << "Input rejected after " << max_attempts << " failed attempts.\n"; 
		std::cout << "You entered: " << user_input << std::endl; 
		std::cout << "Account Number = " << account_number << 
		std::endl; 
		
		// Return correct exit code 
		return 3; 
	} 
	
	// User_input contains a safely-copied, null-terminated string. 
	std::cout << "You entered: " << user_input << std::endl; std::cout << "Account Number = " << account_number << std::endl; 
	return 0; 
} 
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu 
// Debug program: F5 or Debug > Start Debugging menu