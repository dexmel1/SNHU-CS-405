// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer 
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
} */

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // Initially the collection should be empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0U);

    // Add a single entry
    add_entries(1);

    // After adding, the collection should not be empty
    EXPECT_FALSE(collection->empty());
    // And the size must be exactly 1
    EXPECT_EQ(collection->size(), 1U);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0U);

    add_entries(5);

    // Size must now be 5
    EXPECT_EQ(collection->size(), 5U);

}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsAlwaysGreaterOrEqualToSize)
{
    // 0 entries
    EXPECT_GE(collection->max_size(), collection->size());

    // 1 entry
    add_entries(1);
    EXPECT_EQ(collection->size(), 1U);
    EXPECT_GE(collection->max_size(), collection->size());

    // 5 entries total (add 4 more)
    add_entries(4);
    EXPECT_EQ(collection->size(), 5U);
    EXPECT_GE(collection->max_size(), collection->size());

    // 10 entries total (add 5 more)
    add_entries(5);
    EXPECT_EQ(collection->size(), 10U);
    EXPECT_GE(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsAlwaysGreaterOrEqualToSize)
{
    // 0 entries
    EXPECT_GE(collection->capacity(), collection->size());

    // 1 entry
    add_entries(1);
    EXPECT_EQ(collection->size(), 1U);
    EXPECT_GE(collection->capacity(), collection->size());

    // 5 entries total
    add_entries(4);
    EXPECT_EQ(collection->size(), 5U);
    EXPECT_GE(collection->capacity(), collection->size());

    // 10 entries total
    add_entries(5);
    EXPECT_EQ(collection->size(), 10U);
    EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizingLargerIncreasesCollectionSize)
{
    ASSERT_EQ(collection->size(), 0U);

    // Resize up to 10 elements
    collection->resize(10);

    // Size should now be 10
    EXPECT_EQ(collection->size(), 10U);

    // All newly-created elements should be default-initialized (0 for int)
    for (const auto& value : *collection)
    {
        EXPECT_EQ(value, 0);
    }
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizingSmallerDecreasesCollectionSize)
{
    // Fill with known, random values
    add_entries(10);
    ASSERT_EQ(collection->size(), 10U);

    // Copy original vector to verify preserved elements after shrinking
    std::vector<int> original = *collection;

    // Shrink down to 5
    collection->resize(5);

    // Size should now be 5
    EXPECT_EQ(collection->size(), 5U);

    // First 5 elements should be unchanged
    for (size_t i = 0; i < collection->size(); ++i)
    {
        EXPECT_EQ(collection->at(i), original.at(i));
    }
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingToZeroClearsCollection)
{
	// Add random values
    add_entries(5);
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 5U);

	// Shrink down to 0
    collection->resize(0);

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesAllElements)
{
    add_entries(10);
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 10U);

    collection->clear();

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseRangeErasesAllElements)
{
    add_entries(8);
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 8U);

    collection->erase(collection->begin(), collection->end());

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
    // Start with a few elements so capacity is non-trivial
    add_entries(3);
    auto oldSize = collection->size();
    auto oldCapacity = collection->capacity();

    // Request a larger capacity than current
    size_t requestedCapacity = oldCapacity + 10;
    collection->reserve(requestedCapacity);

    // Size must remain unchanged
    EXPECT_EQ(collection->size(), oldSize);

    // Capacity must be at least what we requested
    EXPECT_GE(collection->capacity(), requestedCapacity);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrowsOutOfRangeOnEmptyCollection)
{
    // The collection is empty; any index is invalid
    EXPECT_THROW(collection->at(0), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexEqualsSize)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5U);

    // Index 5 is just past the last valid element
    EXPECT_THROW(collection->at(collection->size()), std::out_of_range);
}

TEST_F(CollectionTest, CanInsertAndReadBackKnownValues)
{
    // Insert values
    collection->push_back(10);
    collection->push_back(20);
    collection->push_back(30);

    ASSERT_EQ(collection->size(), 3U);

    // Verify the readback of values
    EXPECT_EQ(collection->at(0), 10);
    EXPECT_EQ(collection->at(1), 20);
    EXPECT_EQ(collection->at(2), 30);
}